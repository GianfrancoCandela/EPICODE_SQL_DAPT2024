/* Esplora la tabelle dei prodotti (DimProduct)*/
SELECT *
FROM 
dimproduct;
/*Interroga la tabella dei prodotti (DimProduct) ed esponi in output i campi ProductKey, ProductAlternateKey, EnglishProductName, Color, StandardCost, FinishedGoodsFlag. Il result set deve essere parlante per cui assegna un alias se lo ritieni opportuno.*/
SELECT
ProductKey AS chiaveprimaria,
ProductAlternateKey AS PINO,
WeightUnitMeasureCode,
SizeUnitMeasureCode,
EnglishProductName
FinishedGoodsFlag
FROM
dimproduct;
/*Partendo dalla query scritta nel passaggio precedente, esponi in output i soli prodotti finiti cioè quelli per cui il campo FinishedGoodsFlag è uguale a 1*/

SELECT
ProductKey AS chiaveprimaria,
ProductAlternateKey AS PINO,
WeightUnitMeasureCode,
SizeUnitMeasureCode,
EnglishProductName
FROM
dimproduct

WHERE 
FinishedGoodsFlag = 1; 