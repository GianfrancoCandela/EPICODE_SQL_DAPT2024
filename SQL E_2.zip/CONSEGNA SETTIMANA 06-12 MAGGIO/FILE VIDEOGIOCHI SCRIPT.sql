INSERT INTO STORE ( INDIRIZZO, TELEFONO) 
VALUES
("Via Roma 123 Milano", "+39021234567"),
("Corso Italia 456 Roma", "+390813456789"),
("Piazza San Marco 789 Venezia",  "+390419876543"),
("Viale degli Ulivi 234  Napoli", "+390813456789"),
(" Via Torino 567 Torino",  +39055345678),
("Corso Vittorio Emanuele 890 Firenze", "+390518765432"),
("Piazza del Duomo 123 Bologna", "+390102345678"),
("Via Garibaldi 456 Genova", ", +390508765432"),
("Lungarno Mediceo 789 Pisa", "+390912345678") ,
("Corso Cavour 101 Palermo", "+390912345678"
);

INSERT  INTO IMPIEGATO (CODICE_FISCALE, NOME, TITOLO_STUDIO, RECAPITO) 
VALUES 
("ABC12345XYZ67890", "Mario Rossi", "Laurea in Economia", "mailto:mario.rossi@email.com"),          
("DEF67890XYZ12345", "Anna Verdi", "Diploma di Ragioneria", "anna.verdi@email.com"),
("GHI12345XYZ67890","Luigi Bianchi", "Laurea in Informatica", "luigi.bianchi@email.com"), 
("JKL67890XYZ12345", "Laura Neri", "Laurea in Lingue", "laura.neri@email.com"),
("MNO12345XYZ67890", "Andrea Moretti", "Diploma di Geometra", "mailto:andrea.moretti@email.com"), 
("PQR67890XYZ12345", "Giulia Ferrara","Laurea in Psicologia", "giulia.ferrara@email.com"),
("STU12345XYZ67890", "Marco Esposito", "Diploma di Elettronica", "marco.esposito@email.com"),
("VWX67890XYZ12345", "Sara Romano", "Laurea in Giurisprudenza", "sara.romano@email.com"),
("ZRBDLP87C05V890V",   "Roberto De Luca", "Diploma di Informatica", "roberto.deluca@email.com"),
("BCD67890XYZ12345", "Elena Santoro", "Laurea in Lettere", "elena.santoro@email.com" 

);


INSERT INTO  SERVIZIO_IMPIEGATO (CODICE_FISCALE, COD_STORE, DATA_INIZIO, DATA_FINE, CARICA)
VALUES 
("ABC12345XYZ67890","1", "2023-01-01","2023-12-31", "Cassiere"),
("DEF67890XYZ12345","2","2023-02-01", "2023-11-30", "Commesso"),
("GHI12345XYZ67890","3","2023-03-01", "2023-10-31", "Magazziniere"),
("JKL67890XYZ12345","4", "2023-04-01","2023-09-30", "Addetto alle vendite"),
("MNO12345XYZ67890","5","2023-05-01", "2023-08-31", "Addetto alle pulizie"),
("PQR67890XYZ12345","6", "2023-06-01","2023-07-31", "Commesso"),
("STU12345XYZ67890","7","2023-07-01", "2023-06-30", "Commesso"),
("VWX67890XYZ12345","8","2023-08-01", "2023-05-31", "Cassiere"),
("ZRBDLP87C05V890V","9","2023-09-01", "2023-04-30", "Cassiere"),
("BCD67890XYZ12345","10","2023-10-01","2023-03-31",  "Cassiere"
); 

