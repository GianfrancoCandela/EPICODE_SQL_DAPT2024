/*1 Scrivi una query per verificare che il campo ProductKey nella tabella DimProduct sia una chiave primaria. Quali considerazioni/ragionamenti è necessario che tu faccia? */ 

SELECT 
    ProductKey, COUNT(*)
FROM
    dimproduct
GROUP BY ProductKey
HAVING ProductKey > 1; 

/* MODO DUE PER TROVARE*/

SELECT  COUNT(ProductKey), COUNT(DISTINCT ProductKey ) 
FROM dimproduct


/* 2 Scrivi una query per verificare che la combinazione dei campi SalesOrderNumber e SalesOrderLineNumber sia una PK */ 

SELECT SalesOrderNumber, SalesOrderLineNumber, COUNT(*) AS somma 
FROM 
factresellersales
GROUP BY 
SalesOrderNumber,  SalesOrderLineNumber
HAVING somma >1 
;

/*MODO DUE*/

SELECT DISTINCT SalesOrderNumber, SalesOrderLineNumber 
FROM factresellersales 
; 


/* 3.Conta il numero transazioni (SalesOrderLineNumber) realizzate ogni giorno a partire dal 1 Gennaio 2020. */

SELECT 
OrderDate AS giorno, COUNT( DISTINCT SalesOrderNumber)  AS NumeroTransizioni 
FROM 
factresellersales
WHERE YEAR (OrderDate) > 2019 
GROUP BY OrderDate 
ORDER BY OrderDate
; 








/* 4 .Calcola il fatturato totale (FactResellerSales.SalesAmount), la quantità totale venduta (FactResellerSales.OrderQuantity)
 e il prezzo medio di vendita (FactResellerSales.UnitPrice) per prodotto (DimProduct) a partire dal 1 Gennaio 2020. 
 Il result set deve esporre pertanto il nome del prodotto, l fatturato totale, la quantità totale venduta e il prezzo medio di vendita. I campi in output devono essere parlanti! */


SELECT
    prod.EnglishProductName AS nome_prodotto,
    SUM(reselsales.SalesAmount) AS fatturato_totale,
    SUM(reselsales.OrderQuantity) AS quantita_totale_venduta,
    AVG(reselsales.UnitPrice) AS prezzo_medio_vendita
FROM
    factresellersales AS reselsales
        JOIN
    dimproduct AS prod ON reselsales.productkey = prod.productkey
WHERE
    reselsales.OrderDate >= '2020-01-01'
GROUP BY
    prod.EnglishProductName
ORDER BY
    prod.EnglishProductName;
    
    /*5.Calcola il fatturato totale (FactResellerSales.SalesAmount) e la quantità totale venduta (FactResellerSales.OrderQuantity) per Categoria prodotto (DimProductCategory). 
    Il result set deve esporre pertanto il nome della categoria prodotto, il fatturato totale e la quantità totale venduta. I campi in output devono essere parlanti! */
    
 SELECT
    dimproductcategory.EnglishProductCategoryName,
    SUM(FactResellerSales.SalesAmount) AS Fatturato_totale,
    SUM(FactResellerSales.OrderQuantity) AS Quantita_Totale_venduta
FROM
    factresellersales
    JOIN
    dimproduct ON factresellersales.productkey = dimproduct.productkey
    JOIN
    dimproductsubcategory ON dimproductsubcategory.ProductSubcategoryKey = dimproduct.ProductSubcategoryKey
    JOIN
    dimproductcategory ON dimproductcategory.ProductCategoryKey = dimproductsubcategory.ProductcategoryKey
GROUP BY
    dimproductcategory.EnglishProductCategoryName;

    
/*6.Calcola il fatturato totale per area città (DimGeography.City) realizzato a partire dal 1 Gennaio 2020. Il result set deve esporre l’elenco delle città con fatturato realizzato superiore a 60K.*/
 SELECT
    dimgeography.City,
    SUM(factresellersales.SalesAmount)
FROM
    dimgeography
    JOIN
    dimreseller ON dimreseller.GeographyKey = dimgeography.GeographyKey
    JOIN
    factresellersales ON factresellersales.ResellerKey = dimreseller.ResellerKey
WHERE
OrderDate >= '2020-01-01'
GROUP BY
    dimgeography.City
HAVING
    SUM(factresellersales.SalesAmount) >= 60000;   
  
    
    
    
    
