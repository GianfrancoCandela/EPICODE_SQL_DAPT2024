/*Esercizio 1 Cominciate facendo un’analisi esplorativa del database, ad esempio: 
Fate un elenco di tutte le tabelle. 
Visualizzate le prime 10 righe della tabella Album. 
Trovate il numero totale di canzoni della tabella Tracks. 
Trovate i diversi generi presenti nella tabella Genere */ 

SHOW TABLES ; 

SELECT AlbumId, Title, ArtistId 
FROM album
LIMIT 10 ; 

SELECT DISTINCT COUNT(*) Name
FROM chinook.track
;

SELECT DISTINCT  genre.Name
FROM genre 
; 


/*Esercizio 2 Recuperate il nome di tutte le tracce e del genere associato.*/

SELECT DISTINCT  genre.Name, track.Name
FROM genre JOIN track  ON  genre.GenreId = track.GenreId

;

/*3 Recuperate il nome di tutti gli artisti che hanno almeno un album nel database. Esistono artisti senza album nel database?*/ 

SELECT DISTINCT artist.Name, album.Title
FROM album right join artist on album.AlbumId = artist.ArtistId
 WHERE  
 NOT Title = "NULL" ; 


SELECT 
    artist.Name, album.Title
FROM
    album
        JOIN
    artist ON album.AlbumId = artist.ArtistId
WHERE
    album > 0;  


/* Esercizio 4 Esercizio Join Recuperate il nome di tutte le tracce, del genere associato e della tipologia di media. Esiste un modo per recuperare il nome della tipologia di media? */ 

SELECT 
    track.Name, genre.Name, mediatype.Name
FROM
    genre
        JOIN
    track ON genre.GenreId = track.GenreId
        JOIN
    mediatype ON mediatype.MediaTypeId = track.MediaTypeId; 
/* 5 Elencate i nomi di tutti gli artisti e dei loro album */ 

SELECT 
artist.Name, album.Title
FROM
artist 
LEFT JOIN 
album ON artist.ArtistId = album.ArtistId ; 


SELECT track.NAME, genre.Name
FROM track
JOIN genre ON genre.GenreId = genre.GenreId
WHERE  genre.Name LIKE "POP" or genre.Name LIKE "ROCK"; 







