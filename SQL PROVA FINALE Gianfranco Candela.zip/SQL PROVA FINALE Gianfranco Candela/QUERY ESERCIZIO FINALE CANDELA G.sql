/*1. Verificare che i campi definiti come PK siano univoci. */ 
-- iN QUESTA QUERY HO INSERITO LA CHIAVE PRIMARIA NELLA SELECT, RAGGRUPPATO E FILTRATO CON L'HAVING.  
-- IN QUESTO MODO SE AVESSI AVUTO LA CHIAVE RIPETUTA NELLA TABELLA MI SAREBBE COMPARSA NELL'OUTPUT. 
SELECT Id_Prodotto
FROM prodotto
GROUP BY Id_Prodotto
HAVING COUNT(*) > 1;  

SELECT Id_Regione
FROM stati_regioni
GROUP BY Id_Regione
HAVING COUNT(*) > 1; 

SELECT ID_Transaction
FROM vendite
GROUP BY ID_Transaction
HAVING COUNT(*) > 1;  

 -- IN QUESTO MODO VEDO CHE LE VOCI SONO SOLTANTO 15, MA SONO PROVE CHE HO VOLUTO FARE GIUSTO PER SPERIMENTARE.  
 
Select count(Id_Prodotto) 
from  prodotto ;  

Select count( distinct Id_Prodotto) 
from  prodotto ;  

-- 3 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 
-- IO HO STRUTTURATO UN PO' INVOLOTARIAMENTE LA TABELLA VENDITA AVENDO IL PREZZO TOTALE IN BASE ALLE QUANTITA' VENDUTE. 
-- PARTENDO DA QUESTO PRESSUPOSTO, AVENDO ANCHE POCHE VOCI HO ELENCATO I PRODOTTI RIPORTANDO IL NOME NELLA SELECT, PREZZO CON UN ALIAS E L'ANNO. 
-- NELL'OUTPUT PER ESEMPIO, NELLA PRIMA RIGA  HO SAILOR MOON CHE FATTURA 39.98 NEL 2024, INFATTI NELLA TABELLA RISULTANO VENDUTE DUE BAMBOLE 19.99

SELECT Nome_Prodotto, Prezzo_Totale AS FATTURATO_TOTALE , year(Data_Vendita)  AS ANNO 
FROM prodotto join vendite on prodotto.Id_Prodotto = vendite.Id_Prodotto 
ORDER BY ANNO DESC ; 


-- 4 Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 
-- PREMETTO CHE QUESTA COSA DELLE REGIONI/BARRA STATI MI HA FATTO UN PO' PENSARE. NONOSTANTE GEOGRAFICAMENTE NON SIA ATTENDIBILE 
-- HO VOLONTARIAMENTE INSERITO PAESI A CASO CONCENTRANDOMI PIU' CHE ALTRO SUL RISULTATO DI QUESTA QUERY. 
-- COME OUTPUT HO OTTENUTO IL NOME REGIONE, IL FATTURATO PER OGNI PAESE E PER ANNO A PARTIRE DAL 2023.


SELECT Nome_Regione, SUM(Prezzo_Totale) AS FATTURATO_TOTALE, YEAR(Data_Vendita) AS ANNO
FROM prodotto
JOIN vendite ON prodotto.Id_Prodotto = vendite.Id_Prodotto
JOIN stati_regioni ON stati_regioni.Id_Regione = vendite.Id_Regione
GROUP BY Nome_Regione, ANNO
ORDER BY ANNO, FATTURATO_TOTALE DESC ; 

-- 5  Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
-- NELL'OUTPUT HO LA CATEGORIA, LA QUANTITA' VENDUTA PRECEDUTA DAL SUM E IL PREZZO TOTALE. 
-- HO RAGGRUPPATO PER CATEOGIA, DATO UN ORDINE DESC E HO MESSO UN LIMIT 2. 
-- LA TABELLA MOSTRA CHE LEGO E BAMBOLE HANNO VENDUTO DI PIU' E OTTENGO ANCHE IL FATTURATO. 

SELECT Categoria, SUM(Quant_Venduta) AS TOTALE_VENDITE, SUM(Prezzo_Totale) AS FATTURATO_TOTALE
FROM prodotto join vendite ON prodotto.Id_Prodotto = vendite.Id_Prodotto 
GROUP BY Categoria  
ORDER BY TOTALE_VENDITE DESC 
LIMIT 2 ; 

-- 6 Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
-- IN QUESTA QUERY MI SONO ISPIRATO A UN TUO ESEMPIO FATTO A LEZIONE PERCHE' HO TRASCRITTO TUTTE LE LEZIONI. 
-- ONESTAMENTE HO DOVUTO MODIFCARE IL DATABASE E TOGLIERE UN ITEM DA VENDITE. 
-- IN QUESTO MODO CON IL LEFT JOIN E LA CONDIZIONE HO AVUTO IL RISULTATO CHE SPERAVO DI AVERE
-- OVVERO LA BAMBOLA MILAAZUKI E' RIMASTA INVENDUTA. 

SELECT prodotto.*
FROM prodotto
LEFT JOIN vendite ON prodotto.Id_Prodotto = vendite.Id_Prodotto
WHERE vendite.ID_Transaction IS NULL;

-- QUI HO OTTENUTO LO STESSO RISULTATO PENSANDO AL FATTO CHE L'ITEM NON FOSSE PRESENTE IN VENDITE
-- E QUINDI AVEVO L'IDEA DI USARE IL NOT IN, HO PERSO UN PO' DI TEMPO PER LA CONDIZIONE PERCHE' INZIALMENTE NON METTEVO LA SELECT. 

SELECT *
FROM prodotto
WHERE Id_Prodotto NOT IN (SELECT Id_Prodotto FROM vendite); 

-- 7  Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
-- E' STATA LA QUERY PIU' INSIDIOSA. HO DOVUTO FARE UN PO' DI RICERCHE PER SISTEMARE LA SINTASSI E L'ORDINE
-- IL PROBLEMA MAGGIORE E' STATO CAPIRE COME STRUTTURARE IL GROUP BY. SPERIAMO SIA GIUSTA.. 

SELECT 
p.Nome_Prodotto, v.Data_Vendita AS VENDITA_RECENTE
FROM prodotto p JOIN (SELECT  Id_Prodotto, MAX(Data_Vendita) AS Data_Vendita
FROM vendite
GROUP BY Id_Prodotto) AS MaxDataVendita ON p.Id_Prodotto = MaxDataVendita.Id_Prodotto
JOIN vendite v ON MaxDataVendita.Id_Prodotto = v.Id_Prodotto
AND MaxDataVendita.Data_Vendita = v.Data_Vendita ; 















































































































































