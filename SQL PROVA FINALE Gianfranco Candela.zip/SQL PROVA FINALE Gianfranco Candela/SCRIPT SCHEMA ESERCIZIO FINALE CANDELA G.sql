CREATE SCHEMA toysgroupcompany ;

CREATE TABLE toysgroupcompany.prodotto (
  Id_prodotto INT NOT NULL AUTO_INCREMENT,
  Nome_Prodotto VARCHAR(45) NOT NULL,
  Prezzo_Unitario DECIMAL(10,2) NOT NULL,
  Categoria VARCHAR(45) NOT NULL,
  PRIMARY KEY (Id_prodotto));
  
  CREATE TABLE toysgroupcompany.stati_regioni (
  Id_Regione INT NOT NULL AUTO_INCREMENT,
  Nome_Regione VARCHAR(45) NOT NULL,
  PRIMARY KEY (Id_Regione));

CREATE TABLE vendite (
    ID_Transaction VARCHAR(10) PRIMARY KEY,
    Data_Vendita DATE,
    Prezzo_Totale DECIMAL(10,2),
    Quant_Venduta INT,
    Id_Prodotto INT,
    Id_Regione VARCHAR(10), 
    FOREIGN KEY (Id_Prodotto) REFERENCES prodotto(Id_Prodotto), 
    FOREIGN KEY(Id_Regione) REFERENCES stati_regioni(Id_Regione)

); 

ALTER TABLE `toysgroupcompany`.`vendite` 
DROP FOREIGN KEY `vendite_ibfk_1`,
DROP FOREIGN KEY `vendite_ibfk_2`;
ALTER TABLE `toysgroupcompany`.`vendite` 
CHANGE COLUMN `Data_Vendita` `Data_Vendita` DATE NOT NULL ,
CHANGE COLUMN `Prezzo_Totale` `Prezzo_Totale` DECIMAL(10,2) NOT NULL ,
CHANGE COLUMN `Quant_Venduta` `Quant_Venduta` INT NOT NULL ,
CHANGE COLUMN `Id_Prodotto` `Id_Prodotto` INT NOT NULL ,
CHANGE COLUMN `Id_Regione` `Id_Regione` VARCHAR(10) NOT NULL ;
ALTER TABLE `toysgroupcompany`.`vendite` 
ADD CONSTRAINT `vendite_ibfk_1`
  FOREIGN KEY (`Id_Prodotto`)
  REFERENCES `toysgroupcompany`.`prodotto` (`Id_Prodotto`),
ADD CONSTRAINT `vendite_ibfk_2`
  FOREIGN KEY (`Id_Regione`)
  REFERENCES `toysgroupcompany`.`stati_regioni` (`Id_Regione`);
  
  
  INSERT INTO `toysgroupcompany`.`prodotto` (`Id_Prodotto`, `Nome_Prodotto`, `Prezzo_Unitario`, `Categoria`, `Provenienza`)
VALUES
  (1, 'SailorMoon', 19.99, 'Bambole', 'USA'),
  (2, 'Barbie', 9.99, 'Bambole', 'Cina'),
  (3, 'Hogwart Castello', 59.99, 'Lego', 'Danimarca'),
  (4, 'Rapunzel', 24.99, 'Bambole', 'USA'),
  (5, 'Hogwart Scuola', 14.99, 'Lego', 'Cina'),
  (6, 'Gioco da Tavolo Monopoli', 29.99, 'Giochi da Tavolo', 'USA'),
  (7, 'Giocattolo Educativo ABC', 12.99, 'Giochi Educativi', 'Germania'),
  (8, 'Hogwart Treno', 49.99, 'Lego', 'Giappone'),
  (9, 'Puzzle 1000 Pezzi', 19.99, 'Puzzle', 'Italia'),
  (10, 'Gioco di Carte UNO', 8.99, 'Giochi di Carte', 'USA'),
  (11, 'Pistola ad Acqua', 7.99, 'Giochi Estivi', 'Cina'),
  (12, 'CreamyMami', 39.99, 'Bambole', 'Francia'),
  (13, 'Scivolo da Giardino', 89.99, 'Giochi da Esterno', 'Italia'),
  (14, 'MilaAzuki', 34.99, 'Bambole', 'Cina'),
  (15, 'Pista per Macchinine', 24.99, 'Veicoli', 'USA');
  
  
  INSERT INTO `toysgroupcompany`.`regioni` (`Id_Regione`, `Nome_Regione`)
VALUES
  ('S100', 'Stati Uniti'),
  ('S101', 'Cina'),
  ('S102', 'Danimarca'),
  ('S103', 'Giappone'),
  ('S104', 'Italia'),
  ('S105', 'Germania'),
  ('S106', 'Francia'),
  ('S107', 'Regno Unito');


  
  
  
  