/*Scrivere il codice SQL (da scrivere su un documento testo dopo averlo testato) che 
restituisca le seguenti informazioni:*/
/*Parte 1*/
/*1. Marca e Colore delle Auto di che costano più di 26.000 €*/
SELECT marca, colore
FROM auto
WHERE prezzo > 26000.00;

/*2. Tutti i proprietari di un’auto di colore ROSSO*/
SELECT A.nome_proprietario
FROM proprietari_auto A
JOIN auto B ON A.idauto = B.idauto
WHERE B.colore = 'Rosso';

/*3. Costo totale di tutte le auto con Cilindrata superiore a 1600*/
SELECT  SUM(prezzo) AS Costototale
FROM auto 
WHERE cilindrata > 1600;

/* 4. Targa e Nome del proprietario delle Auto in una concessionaria della Città di Roma*/
/*con la query seguente otteniamo le targhe ed i nomi proprietario delle auto delle concessionarie di roma*/
SELECT A.targa, A.nome_proprietario
FROM proprietari_auto A 
JOIN concessionaria B ON A.idconcessionaria = B.idconcessionaria
WHERE B.citta = 'Roma';

/* con questa otteniamo lo stesso risultato ma per una sola concessionaria di Roma*/
SELECT B.targa, B.nome_proprietario
FROM ( 
SELECT * FROM second_auto.concessionaria where citta = 'Roma') A
JOIN proprietari_auto B ON A.idconcessionaria = B.idconcessionaria
WHERE A.idconcessionaria = 1;

/*5. Per ogni Concessionaria, il numero di Auto*/
SELECT nome_concessionaria, quantita_auto
FROM concessionaria;

/*6. Il Responsabile di Concessionaria di tutte le auto con Cambio Automatico e Anno 
Acquisto 2015*/
SELECT DISTINCT A.nome_responsabile
FROM responsabili A 
JOIN concessionaria B ON A.idresponsabile = B.idresponsabile
JOIN proprietari_auto C ON B.idconcessionaria = C.idconcessionaria
JOIN auto D ON C.idauto = D.idauto
WHERE D.tipo_cambio = 'Automatico' AND C.anno_acquisto = 2015;

/*PARTE 2*/
/*1. Per ciascuna TARGA il colore, il prezzo e la città in cui si trova il veicolo*/
SELECT A.targa, B.colore, B.prezzo, A.citta_residenza
FROM proprietari_auto A 
JOIN auto B ON A.idauto = B.idauto;

/*2. Le auto con almeno tre Proprietari*/
SELECT modello_auto
FROM (
SELECT A.modello_auto, B.idauto, COUNT(B.idauto) AS tot_propauto
FROM auto A 
JOIN proprietari_auto B ON A.idauto = B.idauto
GROUP BY B.idauto
ORDER BY tot_propauto DESC) AS count
WHERE tot_propauto >= 3;

/*3. La targa delle auto vendute nel 2021*/
SELECT targa
FROM proprietari_auto
WHERE anno_vendita = 2021;

/*4. La regione con più auto (trovare un modo per associare la Regione)*/
SELECT regione
FROM
(SELECT regione, COUNT(regione) AS num_auto
FROM proprietari_auto
GROUP BY regione
ORDER BY num_auto DESC
LIMIT 1) AS count;

/*5. La Targa delle auto che si trovano a Lucca, con cambio automatico, colore rosso, 
di proprietari residenti a Lucca */
SELECT targa
FROM proprietari_auto A 
JOIN auto B ON A.idauto = B.idauto
JOIN concessionaria C ON A.idconcessionaria = C.idconcessionaria
WHERE C.citta = 'Lucca'
AND B.tipo_cambio = 'Automatico'
AND B.colore = 'Rosso'
AND A.citta_residenza = 'Lucca'