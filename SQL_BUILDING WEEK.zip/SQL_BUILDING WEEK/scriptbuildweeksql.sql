/*creazione schema e default schema*/
CREATE SCHEMA second_auto;
USE second_auto;

/*creazione tabelle*/
CREATE TABLE `second_auto`.`responsabili` (
  `idresponsabile` INT NOT NULL AUTO_INCREMENT,
  `nome_responsabile` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idresponsabile`));
  
  CREATE TABLE `second_auto`.`concessionaria` (
  `idconcessionaria` INT NOT NULL AUTO_INCREMENT,
  `nome_concessionaria` VARCHAR(45) NOT NULL,
  `idresponsabile` INT NOT NULL,
  `citta` VARCHAR(45) NOT NULL,
  `indirizzo` VARCHAR(45) NOT NULL,
  `telefono` VARCHAR(45) NOT NULL,
  `quantita_auto` INT NOT NULL,
  PRIMARY KEY (`idconcessionaria`));
  
  CREATE TABLE `second_auto`.`auto` (
  `idauto` INT NOT NULL AUTO_INCREMENT,
  `marca` VARCHAR(45) NOT NULL,
  `modello_auto` VARCHAR(45) NOT NULL,
  `colore` VARCHAR(45) NOT NULL,
  `cilindrata` INT NOT NULL,
  `tipo_cambio` VARCHAR(45) NOT NULL,
  `prezzo` DECIMAL(13,2) NOT NULL,
  PRIMARY KEY (`idauto`));

CREATE TABLE `second_auto`.`proprietari_auto` (
  `targa` VARCHAR(45) NOT NULL,
  `idproprietario` INT NOT NULL,
  `nome_proprietario` VARCHAR(45) NOT NULL,
  `citta_residenza` VARCHAR(45) NOT NULL,
  `regione` VARCHAR(45) NOT NULL,
  `idauto` INT NOT NULL,
  `idconcessionaria` INT NOT NULL,
  `anno_acquisto` YEAR NOT NULL,
  `anno_vendita` YEAR NOT NULL,
  PRIMARY KEY (`targa`));
  
  /*inseriamo FK*/
  ALTER TABLE `second_auto`.`concessionaria` 
ADD INDEX `resp_conc_idx` (`idresponsabile` ASC) VISIBLE;
;
ALTER TABLE `second_auto`.`concessionaria` 
ADD CONSTRAINT `resp_conc`
  FOREIGN KEY (`idresponsabile`)
  REFERENCES `second_auto`.`responsabili` (`idresponsabile`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;
  
  ALTER TABLE `second_auto`.`proprietari_auto` 
ADD INDEX `auto_prop_idx` (`idauto` ASC) VISIBLE,
ADD INDEX `conc_prop_idx` (`idconcessionaria` ASC) VISIBLE;
;
ALTER TABLE `second_auto`.`proprietari_auto` 
ADD CONSTRAINT `auto_prop`
  FOREIGN KEY (`idauto`)
  REFERENCES `second_auto`.`auto` (`idauto`)
  ON DELETE CASCADE
  ON UPDATE CASCADE,
ADD CONSTRAINT `conc_prop`
  FOREIGN KEY (`idconcessionaria`)
  REFERENCES `second_auto`.`concessionaria` (`idconcessionaria`)
  ON DELETE CASCADE
  ON UPDATE CASCADE;
  
  /*popoliamo le tabelle*/
INSERT INTO `second_auto`.`responsabili` (`nome_responsabile`)
VALUES 
  ('Mario Rossi'),
  ('Luca Bianchi'),
  ('Giulia Verdi'),
  ('Anna Neri'),
  ('Paolo Russo');
  
INSERT INTO `second_auto`.`auto` 
(`marca`, `modello_auto`, `colore`, `cilindrata`, `tipo_cambio`, `prezzo`)
VALUES
('Fiat', 'Punto', 'Rosso', 1200, 'Manuale', 12000.00),
('Fiat', '500', 'Bianco', 1200, 'Manuale', 13000.00),
('Fiat', 'Panda', 'Blu', 1000, 'Manuale', 11000.00),
('Fiat', 'Tipo', 'Nero', 1600, 'Automatico', 20000.00),
('Fiat', '500L', 'Grigio', 1400, 'Manuale', 18000.00),
('Fiat', 'Doblo', 'Rosso', 1600, 'Manuale', 22000.00),
('Fiat', 'Qubo', 'Verde', 1200, 'Automatico', 15000.00),
('Fiat', 'Freemont', 'Nero', 1600, 'Manuale', 25000.00),
('Fiat', 'Punto Evo', 'Blu', 1400, 'Manuale', 16000.00),
('Fiat', 'Bravo', 'Grigio', 1400, 'Automatico', 21000.00),
('Ford', 'Fiesta', 'Rosso', 1200, 'Manuale', 14000.00),
('Ford', 'Focus', 'Blu', 1400, 'Automatico', 22000.00),
('Ford', 'Kuga', 'Nero', 1800, 'Manuale', 25000.00),
('Ford', 'EcoSport', 'Bianco', 1400, 'Manuale', 19000.00),
('Ford', 'Puma', 'Grigio', 1400, 'Automatico', 21000.00),
('Ford', 'Mondeo', 'Rosso', 2000, 'Manuale', 27000.00),
('Ford', 'Mustang', 'Blu', 3400, 'Automatico', 50000.00),
('Ford', 'Galaxy', 'Nero', 2000, 'Manuale', 30000.00),
('Ford', 'S-Max', 'Grigio', 1800, 'Automatico', 32000.00),
('Ford', 'Ranger', 'Bianco', 3000, 'Manuale', 35000.00),
('Volkswagen', 'Golf', 'Bianco', 1600, 'Manuale', 24000.00),
('Volkswagen', 'Polo', 'Rosso', 1600, 'Manuale', 16000.00),
('Volkswagen', 'Tiguan', 'Nero', 1800, 'Automatico', 32000.00),
('Volkswagen', 'Passat', 'Grigio', 1400, 'Manuale', 28000.00),
('Volkswagen', 'T-Roc', 'Blu', 1200, 'Automatico', 23000.00),
('Volkswagen', 'Up!', 'Verde', 1000, 'Manuale', 14000.00),
('Volkswagen', 'Arteon', 'Nero', 1800, 'Automatico', 45000.00),
('Volkswagen', 'T-Cross', 'Rosso', 2200, 'Manuale', 22000.00),
('Volkswagen', 'Caddy', 'Blu', 2000, 'Manuale', 30000.00),
('Volkswagen', 'Touran', 'Bianco', 2000, 'Automatico', 35000.00),
('Renault', 'Clio', 'Bianco', 1000, 'Manuale', 15000.00),
('Renault', 'Captur', 'Rosso', 1400, 'Manuale', 20000.00),
('Renault', 'Megane', 'Nero', 1600, 'Automatico', 26000.00),
('Renault', 'Kadjar', 'Grigio', 1400, 'Manuale', 24000.00),
('Renault', 'Talisman', 'Blu', 1200, 'Automatico', 33000.00),
('Renault', 'Zoe', 'Verde', 1200, 'Automatico', 25000.00),
('Renault', 'Scenic', 'Rosso', 1400, 'Manuale', 27000.00),
('Renault', 'Koleos', 'Nero', 1600, 'Automatico', 35000.00),
('Renault', 'Espace', 'Grigio', 2000, 'Manuale', 40000.00),
('Renault', 'Twizy', 'Blu', 1000, 'Automatico', 10000.00),
('Fiat', 'Uno', 'Verde', 1000, 'Manuale', 11000.00),
('Fiat', 'Multipla', 'Grigio', 1600, 'Manuale', 19000.00),
('Fiat', 'Croma', 'Blu', 1900, 'Automatico', 22000.00),
('Ford', 'Ka', 'Bianco', 1200, 'Manuale', 13000.00),
('Ford', 'B-Max', 'Rosso', 1400, 'Automatico', 18000.00),
('Volkswagen', 'Sharan', 'Nero', 2000, 'Manuale', 38000.00),
('Volkswagen', 'Taro', 'Grigio', 2600, 'Automatico', 26000.00),
('Renault', 'Modus', 'Blu', 1200, 'Manuale', 14000.00),
('Fiat', '500XL', 'Grigio', 1600, 'Automatico', 19000.00),
('Fiat', 'Panda4x4', 'Rossa', 1400, 'Manuale', 14000.00);

INSERT INTO `second_auto`.`concessionaria` 
(`nome_concessionaria`, `idresponsabile`, `citta`, `indirizzo`, `telefono`, `quantita_auto`)
VALUES
('Autoitalia Roma', 1, 'Roma', 'Via Appia Nuova 123', '06 1234567', 50),
('Milano Motori', 2, 'Milano', 'Corso Buenos Aires 78', '02 2345678', 45),
('Napoli Motors', 3, 'Napoli', 'Via Toledo 45', '081 3456789', 40),
('Torino Auto', 4, 'Torino', 'Corso Vittorio Emanuele II 56', '011 4567890', 35),
('Firenze Automobili', 5, 'Firenze', 'Via dei Martelli 34', '055 5678901', 60),
('Bologna Car', 1, 'Bologna', 'Via Indipendenza 67', '051 6789012', 55),
('Venezia Auto', 2, 'Venezia', 'Piazzale Roma 89', '041 7890123', 50),
('Genova Motors', 3, 'Genova', 'Corso Italia 23', '010 8901234', 45),
('Bari Motori', 4, 'Bari', 'Via Sparano 12', '080 9012345', 40),
('Palermo Cars', 5, 'Palermo', 'Via Maqueda 78', '091 0123456', 35),
('Catania Auto', 1, 'Catania', 'Via Etnea 56', '095 1234567', 50),
('Verona Motors', 2, 'Verona', 'Corso Porta Nuova 34', '045 2345678', 45),
('Trieste Auto', 3, 'Trieste', 'Piazza Italia 23', '040 3456789', 40),
('Parma Motors', 4, 'Parma', 'Strada Farini 12', '0521 4567890', 35),
('Perugia Automobili', 5, 'Perugia', 'Corso Vannucci 78', '075 5678901', 60),
('Pescara Auto', 1, 'Pescara', 'Via Nicola Fabrizi 56', '085 6789012', 55),
('Ancona Motors', 2, 'Ancona', 'Corso Stamira 34', '071 7890123', 50),
('Modena Motors', 3, 'Modena', 'Corso Canalgrande 23', '059 8901234', 45),
('Livorno Cars', 4, 'Livorno', 'Via Grande 12', '0586 9012345', 40),
('Padova Auto', 5, 'Padova', 'Via VIII Febbraio 78', '049 0123456', 35),
('Salerno Motors', 1, 'Salerno', 'Corso Vittorio Emanuele 56', '089 1234567', 50),
('Ravenna Auto', 2, 'Ravenna', 'Via Cavour 34', '0544 2345678', 45),
('Reggio Emilia Cars', 3, 'Reggio Emilia', 'Corso Garibaldi 23', '0522 3456789', 40),
('Siracusa Motors', 4, 'Siracusa', 'Corso Umberto I 12', '0931 4567890', 35),
('Trento Auto', 5, 'Trento', 'Via Belenzani 78', '0461 5678901', 60),
('Sassari Motors', 1, 'Sassari', 'Via Roma 56', '079 6789012', 55),
('Cagliari Auto', 2, 'Cagliari', 'Viale Bonaria 34', '070 7890123', 50),
('Lucca Cars', 3, 'Lucca', 'Via Fillungo 23', '0583 8901234', 45),
('Pistoia Motors', 4, 'Pistoia', 'Piazza del Duomo 12', '0573 9012345', 40),
('Arezzo Auto', 5, 'Arezzo', 'Corso Italia 78', '0575 0123456', 35),
('Udine Motors', 1, 'Udine', 'Piazza della Libertà 56', '0432 1234567', 50),
('Ferrara Auto', 2, 'Ferrara', 'Corso Porta Reno 34', '0532 2345678', 45),
('Forlì Motors', 3, 'Forlì', 'Corso della Repubblica 23', '0543 3456789', 40),
('Latina Cars', 4, 'Latina', 'Via Indipendenza 12', '0773 4567890', 35),
('Messina Motors', 5, 'Messina', 'Via Garibaldi 78', '090 5678901', 60),
('Cremona Auto', 1, 'Cremona', 'Corso Matteotti 56', '0372 6789012', 55),
('Foggia Cars', 2, 'Foggia', 'Corso Vittorio Emanuele II 34', '0881 7890123', 50),
('Grosseto Motors', 3, 'Grosseto', 'Via dei Mille 23', '0564 8901234', 45),
('Novara Auto', 4, 'Novara', 'Corso Cavour 12', '0321 9012345', 40),
('Pisa Motors', 5, 'Pisa', 'Piazza del Duomo 78', '050 0123456', 35),
('Prato Cars', 1, 'Prato', 'Via Magnolfi 56', '0574 1234567', 50),
('Taranto Motors', 2, 'Taranto', 'Corso Due Mari 34', '099 2345678', 45),
('Terni Auto', 3, 'Terni', 'Via Garibaldi 23', '0744 3456789', 40),
('Varese Cars', 4, 'Varese', 'Via Verdi 12', '0332 4567890', 35),
('Vicenza Motors', 5, 'Vicenza', 'Corso Palladio 78', '044 5235776', 29),
('Roma Auto', 1, 'Roma', 'Via Appia Vecchia 13', '06 1434567', 23),
('Milan Auto', 2, 'Milano', 'Corso Matteotti 58', '02 2343628', 35),
('Napoli Auto', 3, 'Napoli', 'Via Brombeis 45', '081 2455789', 30),
('Turin Motors', 4, 'Torino', 'Corso Francia 59', '011 4517891', 25),
('Florence Auto', 5, 'Firenze', 'Via de Pazzi 34', '055 5876901', 38); 

INSERT INTO `second_auto`.`proprietari_auto` 
(`targa`, `idproprietario`, `nome_proprietario`, `citta_residenza`, `regione`, `idauto`, `idconcessionaria`, `anno_acquisto`, `anno_vendita`)
VALUES
('AB123CD', 1, 'Mario Rossi', 'Roma', 'Lazio', 1, 1, 2015, 2020),
('EF456GH', 2, 'Luigi Bianchi', 'Milano', 'Lombardia', 2, 2, 2016, 2021),
('IJ789KL', 3, 'Giovanni Verdi', 'Napoli', 'Campania', 3, 3, 2017, 2022),
('MN012OP', 4, 'Carla Neri', 'Torino', 'Piemonte', 4, 4, 2018, 2023),
('QR345ST', 5, 'Anna Gialli', 'Firenze', 'Toscana', 5, 5, 2019, 2024),
('UV678WX', 6, 'Paolo Viola', 'Bologna', 'Emilia-Romagna', 6, 6, 2020, 2024),
('YZ901AB', 7, 'Laura Azzurri', 'Venezia', 'Veneto', 7, 7, 2021, 2024),
('CD234EF', 8, 'Marco Marroni', 'Genova', 'Liguria', 8, 8, 2022, 2024),
('GH567IJ', 9, 'Elena Rossi', 'Bari', 'Puglia', 9, 9, 2023, 2024),
('KL890MN', 10, 'Alessandro Bianchi', 'Palermo', 'Sicilia', 10, 10, 2015, 2020),
('OP123QR', 11, 'Giulia Verdi', 'Catania', 'Sicilia', 11, 11, 2016, 2021),
('ST456UV', 12, 'Andrea Neri', 'Verona', 'Veneto', 12, 12, 2017, 2022),
('WX789YZ', 13, 'Valentina Gialli', 'Trieste', 'Friuli-Venezia Giulia', 13, 13, 2018, 2023),
('AB012CD', 14, 'Francesco Viola', 'Parma', 'Emilia-Romagna', 14, 14, 2019, 2024),
('EF345GH', 15, 'Martina Azzurri', 'Perugia', 'Umbria', 15, 15, 2020, 2024),
('IJ678KL', 16, 'Nicola Marroni', 'Pescara', 'Abruzzo', 16, 16, 2021, 2024),
('MN901OP', 17, 'Sara Rossi', 'Ancona', 'Marche', 17, 17, 2022, 2024),
('QR234ST', 18, 'Stefano Bianchi', 'Modena', 'Emilia-Romagna', 18, 18, 2023, 2024),
('UV567WX', 19, 'Elisa Verdi', 'Livorno', 'Toscana', 19, 19, 2015, 2020),
('YZ890AB', 20, 'Fabio Neri', 'Padova', 'Veneto', 20, 20, 2016, 2021),
('CD123EF', 21, 'Lucia Gialli', 'Salerno', 'Campania', 21, 21, 2017, 2022),
('GH456IJ', 22, 'Davide Viola', 'Ravenna', 'Emilia-Romagna', 22, 22, 2018, 2023),
('KL789MN', 23, 'Chiara Azzurri', 'Reggio Emilia', 'Emilia-Romagna', 23, 23, 2019, 2024),
('OP012QR', 24, 'Lorenzo Marroni', 'Siracusa', 'Sicilia', 24, 24, 2020, 2024),
('ST345UV', 25, 'Silvia Rossi', 'Trento', 'Trentino-Alto Adige', 25, 25, 2021, 2024),
('WX678YZ', 26, 'Roberto Bianchi', 'Sassari', 'Sardegna', 26, 26, 2022, 2024),
('AB901CD',  1, 'Mario Rossi', 'Roma', 'Lazio', 11, 1, 2023, 2024),
('EF234GH', 28, 'Matteo Neri', 'Lucca', 'Toscana', 28, 28, 2015, 2020),
('IJ567KL', 29, 'Simone Gialli', 'Pistoia', 'Toscana', 29, 29, 2016, 2021),
('MN890OP', 30, 'Elena Viola', 'Arezzo', 'Toscana', 30, 30, 2017, 2022),
('QR123ST', 31, 'Giorgio Azzurri', 'Udine', 'Friuli-Venezia Giulia', 31, 31, 2018, 2023),
('UV456WX', 32, 'Marina Marroni', 'Ferrara', 'Emilia-Romagna', 32, 32, 2019, 2024),
('YZ789AB', 33, 'Giovanna Rossi', 'Forlì', 'Emilia-Romagna', 33, 33, 2020, 2024),
('CD012EF', 34, 'Tommaso Bianchi', 'Latina', 'Lazio', 34, 34, 2021, 2024),
('GH345IJ', 35, 'Rita Verdi', 'Messina', 'Sicilia', 35, 35, 2022, 2024),
('KL678MN', 36, 'Riccardo Neri', 'Cremona', 'Lombardia', 36, 36, 2023, 2024),
('OP901QR', 37, 'Daniela Gialli', 'Foggia', 'Puglia', 37, 37, 2015, 2020),
('ST234UV', 38, 'Luca Viola', 'Grosseto', 'Toscana', 38, 38, 2016, 2021),
('WX567YZ', 39, 'Michele Azzurri', 'Novara', 'Piemonte', 39, 39, 2017, 2022),
('AB890CD', 40, 'Francesca Marroni', 'Pisa', 'Toscana', 40, 40, 2018, 2023),
('EF123GH', 41, 'Alessia Rossi', 'Prato', 'Toscana', 41, 41, 2019, 2024),
('IJ456KL', 42, 'Giulio Bianchi', 'Taranto', 'Puglia', 42, 42, 2020, 2024),
('MN789OP', 43, 'Paola Verdi', 'Terni', 'Umbria', 43, 43, 2021, 2024),
('QR012ST', 44, 'Federico Neri', 'Varese', 'Lombardia', 44, 4, 2022, 2024),
('UV345WX', 45, 'Giada Gialli', 'Vicenza', 'Veneto', 45, 45, 2023, 2024),
('YZ678AB', 46, 'Emanuele Viola', 'Catanzaro', 'Calabria', 46, 6, 2015, 2020),
('CD901EF', 47, 'Camilla Azzurri', 'Como', 'Lombardia', 47, 47, 2016, 2021),
('GH234IJ', 48, 'Sofia Marroni', 'Lecce', 'Puglia', 48, 48, 2017, 2022),
('KL567MN', 49, 'Pietro Rossi', 'Trento', 'Trentino-Alto Adige', 49, 49, 2018, 2023),
('OP890QR', 50, 'Ginevra Bianchi', 'Sassari', 'Sardegna', 50, 50, 2019, 2024),
('ST123UV', 51, 'Claudio Verdi', 'Cagliari', 'Sardegna', 1, 1, 2020, 2024),
('WX456YZ', 52, 'Luigi Neri', 'Lucca', 'Toscana', 22, 22, 2021, 2024),
('AB789CD', 53, 'Enrico Gialli', 'Pistoia', 'Toscana', 3, 13, 2022, 2024),
('EF012GH', 54, 'Gabriella Viola', 'Arezzo', 'Toscana', 4, 24, 2023, 2024),
('IJ345KL', 55, 'Vittorio Azzurri', 'Udine', 'Friuli-Venezia Giulia', 5, 5, 2015, 2020),
('MN678OP', 56, 'Monica Marroni', 'Ferrara', 'Emilia-Romagna', 6, 6, 2016, 2021),
('QR901ST', 57, 'Sergio Rossi', 'Forlì', 'Emilia-Romagna', 7, 7, 2017, 2022),
('UV234WX', 58, 'Arianna Bianchi', 'Latina', 'Lazio', 8, 8, 2018, 2023),
('YZ567AB', 59, 'Massimo Verdi', 'Messina', 'Sicilia', 9, 9, 2019, 2024),
('CD890EF', 60, 'Barbara Neri', 'Cremona', 'Lombardia', 10, 10, 2020, 2024),
('GH123IJ', 61, 'Cristina Gialli', 'Foggia', 'Puglia', 11, 11, 2021, 2024),
('KL456MN', 62, 'Leonardo Viola', 'Grosseto', 'Toscana', 12, 12, 2022, 2024),
('OP789QR', 63, 'Matilda Azzurri', 'Novara', 'Piemonte', 13, 13, 2023, 2024),
('ST012UV', 21, 'Lucia Gialli', 'Salerno', 'Campania', 44, 21, 2015, 2020),
('WX345YZ', 65, 'Roberta Rossi', 'Prato', 'Toscana', 15, 15, 2016, 2021),
('AB678CD', 66, 'Alessandro Bianchi', 'Taranto', 'Puglia', 16, 26, 2017, 2022),
('EF901GH', 67, 'Marta Verdi', 'Terni', 'Umbria', 16, 17, 2018, 2023),
('IJ234KL', 68, 'Giorgia Neri', 'Varese', 'Lombardia', 18, 28, 2019, 2024),
('MN567OP', 69, 'Valerio Gialli', 'Vicenza', 'Veneto', 19, 19, 2020, 2024),
('QR890ST', 70, 'Filippo Viola', 'Catanzaro', 'Calabria', 20, 20, 2021, 2024),
('UV123WX', 71, 'Luciana Azzurri', 'Como', 'Lombardia', 21, 21, 2022, 2024),
('YZ456AB', 72, 'Gabriele Marroni', 'Lecce', 'Puglia', 22, 22, 2023, 2024),
('CD789EF', 73, 'Annalisa Rossi', 'Trento', 'Trentino-Alto Adige', 23, 23, 2015, 2020),
('GH012IJ', 74, 'Giovanni Bianchi', 'Sassari', 'Sardegna', 24, 24, 2016, 2021),
('KL345MN', 75, 'Maria Verdi', 'Cagliari', 'Sardegna', 25, 25, 2017, 2022),
('OP678QR', 76, 'Paolo Neri', 'Lucca', 'Toscana', 26, 26, 2018, 2023),
('ST901UV', 77, 'Claudia Gialli', 'Pistoia', 'Toscana', 27, 27, 2019, 2024),
('WX234YZ', 78, 'Daniele Viola', 'Arezzo', 'Toscana', 28, 28, 2020, 2024),
('AB567CD', 79, 'Chiara Azzurri', 'Udine', 'Friuli-Venezia Giulia', 29, 29, 2021, 2024),
('EF890GH', 80, 'Giovanni Marroni', 'Ferrara', 'Emilia-Romagna', 30, 30, 2022, 2024),
('IJ123KL', 81, 'Martina Rossi', 'Forlì', 'Emilia-Romagna', 31, 31, 2023, 2024),
('MN456OP', 82, 'Marco Bianchi', 'Latina', 'Lazio', 32, 32, 2015, 2020),
('QR789ST', 83, 'Stefano Verdi', 'Messina', 'Sicilia', 33, 33, 2016, 2021),
('UV012WX', 84, 'Lorenzo Neri', 'Cremona', 'Lombardia', 34, 34, 2017, 2022),
('YZ345AB', 85, 'Francesca Gialli', 'Foggia', 'Puglia', 35, 35, 2018, 2023),
('CD678EF', 86, 'Andrea Viola', 'Grosseto', 'Toscana', 36, 36, 2019, 2024),
('GH901IJ', 87, 'Luca Azzurri', 'Novara', 'Piemonte', 37, 37, 2020, 2024),
('KL234MN', 88, 'Alessia Marroni', 'Pisa', 'Toscana', 38, 38, 2021, 2024),
('OP567QR', 89, 'Roberto Rossi', 'Prato', 'Toscana', 39, 39, 2022, 2024),
('ST890UV', 90, 'Giulia Bianchi', 'Taranto', 'Puglia', 40, 40, 2023, 2024),
('WX123YZ', 91, 'Nicola Verdi', 'Terni', 'Umbria', 41, 41, 2015, 2020),
('AB456CD', 92, 'Sara Neri', 'Varese', 'Lombardia', 42, 42, 2016, 2021),
('EF789GH', 93, 'Matteo Gialli', 'Vicenza', 'Veneto', 43, 43, 2017, 2022),
('IJ012KL', 94, 'Elena Viola', 'Catanzaro', 'Calabria', 44, 44, 2018, 2023),
('MN345OP', 95, 'Giorgio Azzurri', 'Como', 'Lombardia', 45, 45, 2019, 2024),
('QR678ST', 96, 'Giovanna Marroni', 'Lecce', 'Puglia', 46, 46, 2020, 2024),
('UV901WX', 97, 'Francesco Rossi', 'Trento', 'Trentino-Alto Adige', 47, 47, 2021, 2024),
('YZ234AB', 36, 'Riccardo Neri', 'Cremona', 'Lombardia', 11, 36, 2022, 2024),
('CD567EF', 99, 'Leonardo Verdi', 'Cagliari', 'Sardegna', 49, 49, 2023, 2024),
('GH890IJ', 100, 'Marta Neri', 'Lucca', 'Toscana', 50, 50, 2015, 2020),
('KL123MN', 101, 'Giorgia Gialli', 'Pistoia', 'Toscana', 1, 1, 2016, 2021),
('OP456QR', 102, 'Gianni Viola', 'Arezzo', 'Toscana', 23, 2, 2017, 2022),
('ST789UV', 103, 'Monica Azzurri', 'Udine', 'Friuli-Venezia Giulia', 13, 3, 2018, 2023),
('WX012YZ', 104, 'Massimo Marroni', 'Ferrara', 'Emilia-Romagna', 41, 4, 2019, 2024),
('AB345CD', 105, 'Simone Rossi', 'Forlì', 'Emilia-Romagna', 35, 5, 2016, 2022);

UPDATE `second_auto`.`auto` SET `tipo_cambio` = 'Automatico' WHERE (`idauto` = '28');

/*Ogni gruppo dovrà implementare il sistema per permettere la gestione anche delle 
vendite:*/
/*1. Gestione fatturato per Concessionaria*/
CREATE VIEW Fatturato_Concessionaria as ( 
SELECT C.nome_concessionaria, SUM(B.prezzo) AS fatt_conc
FROM proprietari_auto A 
JOIN auto B ON A.idauto = B.idauto
JOIN concessionaria C ON A.idconcessionaria = C.idconcessionaria
GROUP BY C.nome_concessionaria );

/*2. Gestione Clienti per Concessionaria*/
CREATE VIEW Clienti_concessionarie as ( 
SELECT C.nome_concessionaria, A.idproprietario, COUNT(A.idproprietario) AS n_acquisti
FROM proprietari_auto A 
JOIN concessionaria C ON A.idconcessionaria = C.idconcessionaria
GROUP BY C.nome_concessionaria, A.idproprietario);

CREATE VIEW SalesInfo AS (
 SELECT A.anno_vendita, C.nome_concessionaria, C.citta, A.nome_proprietario AS cliente, B.marca, B.modello_auto, B.prezzo
FROM proprietari_auto A 
JOIN auto B ON A.idauto = B.idauto
JOIN concessionaria C ON A.idconcessionaria = C.idconcessionaria);
  
  
  
